$(document).ready(function(){

	alert('working');

});
