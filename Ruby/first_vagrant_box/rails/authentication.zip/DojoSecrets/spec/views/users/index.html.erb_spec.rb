require 'rails_helper'

RSpec.describe "users/index.html.erb", type: :view do

end
