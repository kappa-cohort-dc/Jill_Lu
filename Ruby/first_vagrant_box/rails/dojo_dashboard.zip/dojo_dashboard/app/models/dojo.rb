class Dojo < ActiveRecord::Base
  validates :branch, :address, :city, :state, presence: true
  validates :state, length: { is: 2 }
end
