require 'test_helper'

class SonglistTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
