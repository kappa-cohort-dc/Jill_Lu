# puts "I am the mammal file"
class Mammal
  def initialize
    @health = 150
  end
  def display_health
    puts @health
  end 
  def breath
    puts "Inhale and exhale"
  end

  def eat
    puts "Yum yum yum"
  end
end
