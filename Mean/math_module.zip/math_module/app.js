var mathlib = require('./mathlib')();
console.log(mathlib);
console.log(mathlib.add(6,20));
console.log(mathlib.multiply(6,20));
console.log(mathlib.square(6));
console.log(mathlib.random(1,10));
