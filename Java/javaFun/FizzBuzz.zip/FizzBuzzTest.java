class FizzBuzzTest{
  public static void main(String[] args){
    FizzBuzz iT = new FizzBuzz();
    String newNumber = iT.fizzBuzz(1);
    System.out.println(newNumber);
  }
}
